print("Selamat datang di Kantor Imigrasi")
print("=================================\n")
print("Silakan masukkan data diri anda")
nama = input("Nama: ")
umur = input("Umur: ")
alamat = input("Alamat: ")

teks = "Nama: {}\nUmur: {}\nAlamat: {}".format(nama, umur, alamat)

file_bio = open("file.txt", "w")
file_bio.write(teks)
file_bio.close()

nama = input("Nama: ")
umur = input("Umur: ")
alamat = input("Alamat: ")

teks = "Nama: {}\nUmur: {}\nAlamat: {}".format(nama, umur, alamat)

file_bio = open("file.txt", "a")
file_bio.write(teks)
file_bio.close()

